ItemEvents.tooltip(event =>{
    event.add("prts:type_d_conductive_circuit","利用初步万子的异化能力得到的产物,提升了导电效率但处于不稳定状态")
    event.add("prts:type_d_conductive_circuit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_resistor","利用初步万子的异化能力得到的产物,电阻率可以根据电流量自动在较小范围内变化")
    event.add("prts:type_d_resistor",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_packaging_unit","利用初步万子的异化能力得到的产物,可以利用其内置的封装系统进行小批量的物品封装")
    event.add("prts:type_d_packaging_unit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_circuit_cross_domain_actuator","利用初步万子的异化能力得到的产物,其可以在一定范围内变化所连接的元件,使其电流导向不同的位置")
    event.add("prts:type_d_circuit_cross_domain_actuator",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_high_voltage_transformation_component","利用初步万子的异化能力得到的产物,可以进行较大幅度的电压转换使其所处的机器高效运作,但并不能避免机器爆炸")
    event.add("prts:type_d_high_voltage_transformation_component",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_risk_management_unit","利用初步万子的异化能力得到的产物,可以在小范围内调节万子浓度,防止万子科技树的机器产生泄露故障")
    event.add("prts:type_d_risk_management_unit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purified_conductive_circuit","利用初步万子的异化能力得到的产物,提升了导电效率但处于不稳定状态,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purified_conductive_circuit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purified_resistor","利用初步万子的异化能力得到的产物,电阻率可以根据电流量自动在较小范围内变化,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purified_resistor",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purified_packaging_unit","利用初步万子的异化能力得到的产物,可以利用其内置的封装系统进行小批量的物品封装,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purified_packaging_unit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purifie_circuit_cross_domain_actuatormain_actuator","利用初步万子的异化能力得到的产物,其可以在一定范围内变化所连接的元件,使其电流导向不同的位置,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purifie_circuit_cross_domain_actuatormain_actuator",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purifie_high_voltage_transformation_component","利用初步万子的异化能力得到的产物,可以进行较大幅度的电压转换使其所处的机器高效运作,但并不能避免机器爆炸,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purifie_high_voltage_transformation_component",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:type_d_purifie_risk_management_unit","利用初步万子的异化能力得到的产物,可以在小范围内调节万子浓度,防止万子科技树的机器产生泄露故障,纯化后更稳定了一些,但仍比C型号差")
    event.add("prts:type_d_purifie_risk_management_unit",Text.of("该阶段物品目前只能用于万子科技,或少量运用于格雷科技").red())

    event.add("prts:waste_material","蚀刻万晶基板的工业生产中不可避免产生的废料,随着你对万子科技的应用加深,废料可以被回收的更彻底")

    event.add("prts:basic_wanzi","通过万子凝练机来塑造的基础原材料,如果在原本的万子理论世界观中,该材料生产几乎无法在LV阶段实现")
    event.add("prts:basic_wanzi",Text.of("详细设定参照万子世界观/找作者获取").red())

    event.add("prts:base_substrate_wanjing","通过万子处理机聚合铁、铜、基础万子三种元素,以此来制作出比同阶段格雷科技的电路基版更好用的电路基板")
    event.add("prts:base_substrate_wanjing",Text.of("但是基础类型仅可以在少部分的格雷科技配方中使用").red())

    event.add("prts:type_one_wanjing_etched_substrate","通过万子蚀刻机将基础万晶基板蚀刻为可用的电路")
    event.add("prts:type_one_wanjing_etched_substrate",Text.of("但是基础类型仅可以在少部分的格雷科技配方中使用").red())

    event.add("prts:iron_grit_dust_wanzi","与致密铁粉尘不同,铁砂尘内部存在有明确的万子微观结构")

    event.add("prts:copper_grit_dust_wanzi","与致密铜粉尘不同,铜砂尘内部存在有明确的万子微观结构")

    event.add("prts:gold_grit_dust_wanzi","与致密金粉尘不同,金砂尘内部存在有明确的万子微观结构")

    event.add("prts:experimental_dsv_component","DSV型实验组件主要用于初步的万子离析,后续迭代版本会使其有更多的能力")
    event.add("prts:experimental_dsv_component",Text.of("该类型组件在LV阶段作用十分有限").red())

    event.add("prts:basic_wanzi_holder","别看这东西小巧玲珑,其内部蕴含着大量的万子,使用不当可以直接导致工厂完蛋")

    event.add("prts:basic_wanzi_resistance_plate","可以在通电状态下抵抗微量的万子外溢,但是其本身的抗冲击力较弱,容易折损")

    event.add("prts:basic_wanzi_redirection_plate","可以在通电状态下重导向表面的微量万子抵达特定位置,但是这块板材更加脆弱了")

    event.add("prts:basic_wanzi_emitter","看似有些简陋的发射器,但可以凝聚微量万子射击指定区域,以此达到扰动特定区域的万子浓度的能力")

    event.add("prts:basic_wanzi_actuator","看起来很简陋的传动器,但是传动效率极高,利用万子的特性,几乎可以无视磨损")

    event.add("prts:basic_wanzi_absorber_plate","这块板材不是一般的脆弱!但是它能提供将游离万子转变为能量降低机器耗能的功能")

    event.add("prts:basic_wanzi_impact_resistant_plate","这块板材融合了多种材料,并且注入了液态钢,因此其稳定性更高了,同时也具备有万子抵抗板和万子重导向板的功能")

    event.add("prts:basic_wanzi_position_corrector","可以矫正一小片区域内的万子波动性等问题,但作用有限")

    event.add("prts:basic_wanzi_film_coating_sprayer","可以对区域内的物品喷射相当微量的万子,以此来产生特定的影响")

    event.add("prts:compression_type_wanzi","通过万子压缩机获得的压缩产物,其已经拥有了被再次压缩为万晶的能力")
})